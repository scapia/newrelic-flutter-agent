class AppConfig {
  static String androidToken =
      "AA47299f5f05f37319adab84290101a7d5b953cd86-NRMA";

  static String iOSToken = "AA47299f5f05f37319adab84290101a7d5b953cd86-NRMA";
}
